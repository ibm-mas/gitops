# fvt-gitops-runner

Helm sub-chart that runs the `fvt-gitops` test suite as a PostSync Kubernetes Job.

## Usage

Add this chart as a sub-chart dependency in an existing GitOps ArgoCD application
(e.g. `500-540-ibm-mas-suite-app-install`) to run the GitOps tests automatically
after every sync.

### values.yaml example

```yaml
fvt-gitops-runner:
  enabled: true
  instance_id: "inst1"
  workspace_id: "masdev"
  test_suite: "manage"
  gitops_version: "9.2.0"
  devops_build_number: "build-1234"
  devops_mongo_uri: ""   # injected via Secret in production
  fvt_gitops_image_repo: "docker-na-public.artifactory.swg-devops.com/wiotp-docker-local/mas-devops/fvt-gitops"
  fvt_gitops_image_tag:  "1.0.0"
```

### Trigger scenarios

| Trigger | Recommended `test_suite` values |
|---|---|
| Complete managed build | `suite`, `manage`, `cluster` |
| Single allowlisted app change | `manage` (or the changed app's suite) |

## Permissions

The Job's ServiceAccount is granted a read-only Role scoped to the resources
queried by the tests (MAS CRs, pods, ArgoCD Applications, CatalogSources).
No write permissions are granted.
